"""Core configuration and utilities"""
